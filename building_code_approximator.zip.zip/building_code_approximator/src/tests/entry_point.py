import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

import unittest

# Import your test modules
from src.tests import test_geo_utils, test_data_utils, test_server
# Create a test suite combining all test modules
def suite():
    test_suite = unittest.TestSuite()
    test_suite.addTest(unittest.defaultTestLoader.loadTestsFromModule(test_geo_utils))
    test_suite.addTest(unittest.defaultTestLoader.loadTestsFromModule(test_data_utils))
    test_suite.addTest(unittest.defaultTestLoader.loadTestsFromModule(test_server))
    return test_suite

if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    result = runner.run(suite())
    if not result.wasSuccessful():
        sys.exit(1)  # Exit with status 1 if there were any failures or errors
