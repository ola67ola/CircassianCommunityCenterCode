import unittest
from unittest.mock import patch, MagicMock
from typing import Tuple, Optional, List
from src.engine.geo_utils import get_country_coordinates, calculate_distance, sort_codes_by_geographical_proximity


class TestGeoUtils(unittest.TestCase):

    @patch('src.engine.geo_utils.requests.get')
    def test_get_country_coordinates_success(self, mock_get):
        # Mock response data for success
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'status': 'OK',
            'results': [
                {'geometry': {'location': {'lat': 34.802075, 'lng': 38.996815}}}
            ]
        }
        mock_get.return_value = mock_response

        # Call function and check result
        result = get_country_coordinates('Syria')
        self.assertEqual(result, (34.802075, 38.996815))

    @patch('src.engine.geo_utils.requests.get')
    def test_get_country_coordinates_failure(self, mock_get):
        # Mock response data for failure
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'status': 'ZERO_RESULTS',
            'error_message': 'No results found'
        }
        mock_get.return_value = mock_response

        # Call function and check result
        result = get_country_coordinates('InvalidCountry')
        self.assertIsNone(result)

    def test_calculate_distance(self):
        # Test distance calculation
        source = (34.802075, 38.996815)  # Coordinates of Syria
        destination = (41.902784, 12.496366)  # Coordinates of Italy
        distance = calculate_distance(source, destination)

        # Assert that the distance is approximately correct (known value ~2338 km)
        self.assertAlmostEqual(distance, 2435, delta=1)

    @patch('src.engine.geo_utils.get_country_coordinates')
    def test_sort_codes_by_geographical_proximity(self, mock_get_coordinates):
        # Mock coordinates of the countries
        coordinates_map = {
            'Syria': (34.802075, 38.996815),
            'France': (46.603354, 1.888334),
            'Germany': (51.165691, 10.451526),
            'Italy': (41.902784, 12.496366),
            'Spain': (40.463667, -3.74922),
            'Portugal': (39.399872, -8.224454)
        }
        mock_get_coordinates.side_effect = lambda country: coordinates_map.get(country)

        # Test sorting functionality
        countries = ["France", "Germany", "Italy", "Spain", "Portugal"]
        sorted_indices = sort_codes_by_geographical_proximity("Syria", countries)
        self.assertEqual(sorted_indices, [2, 1, 0, 3, 4])  # Expected order based on proximity


if __name__ == '__main__':
    unittest.main()
