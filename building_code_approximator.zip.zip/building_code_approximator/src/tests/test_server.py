import unittest
from src.server.app import app  

class TestFlaskServer(unittest.TestCase):

    def setUp(self):
        # Set up a test client for the Flask app
        self.app = app.test_client()
        self.app.testing = True

    def test_distance_endpoint_success(self):
        """
        Test valid JSON POST request
        """
        # Simulate a POST request to the endpoint with valid coordinates
        response = self.app.post('/distance', json={
            'start_lat': 34.0522,   
            'start_lng': -118.2437, 
            'end_lat': 40.7128,     
            'end_lng': -74.0060    
        })

        # Assert that the response status code is 200 OK
        self.assertEqual(response.status_code, 200)

        # Parse and validate the JSON response
        data = response.get_json()
        self.assertIn('distance', data)           
        self.assertGreater(data['distance'], 0)     

    def test_distance_endpoint_missing_parameters(self):
        """
        Test the `/distance` endpoint with missing parameters.
        """
        # Simulate a POST request with no parameters
        response = self.app.post('/distance', json={})  # Empty JSON

        # Assert that the response status code is 400 Bad Request
        self.assertEqual(response.status_code, 400)

        # Parse and validate the JSON response
        data = response.get_json()
        self.assertIn('error', data)                        
        self.assertEqual(data['error'], 'Invalid or missing JSON payload')

    def test_distance_endpoint_partial_parameters(self):
        """
        Test the `/distance` endpoint with only some of the required parameters.
        """
        # Simulate a POST request with partial parameters (missing end_lat and end_lng)
        response = self.app.post('/distance', json={
            'start_lat': 34.0522,
            'start_lng': -118.2437
        })

        # Assert that the response status code is 400 Bad Request
        self.assertEqual(response.status_code, 400)

        # Parse and validate the JSON response
        data = response.get_json()
        self.assertIn('error', data)
        self.assertEqual(data['error'], 'Missing coordinates')

    def test_distance_endpoint_invalid_coordinates(self):
        """
        Test the `/distance` endpoint with invalid (non-numeric) coordinates.
        """
        # Simulate a POST request with invalid coordinates (non-numeric values)
        response = self.app.post('/distance', json={
            'start_lat': 'invalid_lat',
            'start_lng': -118.2437,
            'end_lat': 40.7128,
            'end_lng': -74.0060
        })

        # Assert that the response status code is 400 Bad Request
        self.assertEqual(response.status_code, 400)

        # Parse and validate the JSON response
        data = response.get_json()
        self.assertIn('error', data)

    def test_distance_endpoint_same_coordinates(self):
        """
        Test the `/distance` endpoint with the same start and end coordinates.
        """
        # Simulate a POST request where the start and end coordinates are identical
        response = self.app.post('/distance', json={
            'start_lat': 34.0522,
            'start_lng': -118.2437,
            'end_lat': 34.0522,
            'end_lng': -118.2437
        })

        # Assert that the response status code is 200 OK
        self.assertEqual(response.status_code, 200)

        # Parse and validate the JSON response
        data = response.get_json()
        self.assertIn('distance', data)
        self.assertAlmostEqual(data['distance'], 0, delta=0.001)  # Distance should be approximately 0

if __name__ == '__main__':
    unittest.main()
