import unittest
import pandas as pd
from src.engine.data_utils import encode_data, decode_data, sort_by_cultural_norms


class TestDataUtils(unittest.TestCase):

    def test_encode_data(self):
        data = pd.DataFrame({
            "Climate Zone": ["Arid", "Tropical", "Mediterranean"],
            "Cultural Norms": ["Christianity, Islam", "Buddhism", "Judaism, Atheism"]
        })

        encoded_data = encode_data(data)

        self.assertEqual(encoded_data["Climate Zone"].tolist(), [1, 3, 10])
        self.assertEqual(encoded_data["Cultural Norms"].tolist(), [[1, 0], [5], [6, 15]])

    def test_decode_data(self):
        data = pd.DataFrame({
            "Climate Zone": [1, 3, 10],
            "Cultural Norms": [[1, 0], [5], [6, 15]]
        })

        decoded_data = decode_data(data)

        self.assertEqual(decoded_data["Climate Zone"].tolist(), ["arid", "tropical", "mediterranean"])
        self.assertEqual(decoded_data["Cultural Norms"].tolist(), [
            "christianity, islam",
            "buddhism",
            "judaism, atheism"
        ])
    
    def test_sort_by_cultural_norms(self):
        cultural_norms_series = pd.Series([
            "islam",                  # Exact match
            "buddhism",               # No match
            "christianity",           # No match
            "islamic christianity",   # Partial match
            "islamic sikhism",        # Partial match
            "sikhism"                 # No match 
        ])

        self.assertEqual(sort_by_cultural_norms("islam", cultural_norms_series).tolist(), [0, 3, 4, 1, 2, 5])




if __name__ == "__main__":
    unittest.main()
