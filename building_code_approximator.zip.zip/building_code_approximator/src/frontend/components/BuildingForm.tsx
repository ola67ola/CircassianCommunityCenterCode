import React, { useState } from 'react';
import '../styles/styles.css';
import axios from 'axios';

interface BuildingFormProps {
    currentBuildingInfo: { [key: string]: any };
    setCurrentBuildingInfo: React.Dispatch<React.SetStateAction<{ [key: string]: any }>>;
    serverIp: string;
}

interface BuildingInfo {
    [key: string]: any;
}

const BuildingForm: React.FC<BuildingFormProps> = ({ currentBuildingInfo, setCurrentBuildingInfo, serverIp }) => {
    const [loading, setLoading] = useState(false); // State to track request loading

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setLoading(true); // Indicate loading state

        try {
            const data = await fetchBuildingCode(); // Wait for the server response
            setCurrentBuildingInfo((prevInfo) => ({
                ...prevInfo,
                serverResponse: data, // Ensure state is updated before proceeding
            }));

            console.log("Server Response:", data);
        } catch (error) {
            console.error("Error fetching building code:", error);
        } finally {
            setLoading(false); // Reset loading state
        }
    };

    const fetchBuildingCode = async (): Promise<BuildingInfo | null> => {
        try {
            const response = await axios.post<BuildingInfo>(
                `http://${serverIp}:5000/approximate-building-code`,
                currentBuildingInfo
            );
            return response.data;
        } catch (error) {
            console.error('Error fetching building code:', error);
            return null;
        }
    };

    return (
        <form className="form-container horizontal-form" onSubmit={handleSubmit}>
            <button type="submit" className="form-button" disabled={loading}>
                {loading ? "Processing..." : "GET BUILDING CODE"}
            </button>
        </form>
    );
};

export default BuildingForm;
