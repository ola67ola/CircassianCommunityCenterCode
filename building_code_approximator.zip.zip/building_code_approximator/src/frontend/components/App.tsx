import React, { useState } from 'react';
import BuildingForm from './BuildingForm';
import DatasetTable from './DatasetTable';
import BuildingCodeDisplay from './BuildingCodeDisplay'; // Import the new component
import '../styles/styles.css';
import homepageImage from '../assets/building_code_approximator.jpeg';

// Get the server IP from the environment variable
const serverIp = process.env.REACT_APP_SERVER_IP || '';

const App: React.FC = () => {
    if (!serverIp) {
        console.error('Server IP not found. Please check your environment configuration.');
    }

    const [currentBuildingInfo, setCurrentBuildingInfo] = useState<{ [key: string]: any }>({});

    return (
        <div className="app-container">
            <header className="app-header">
                <img src={homepageImage} alt="Homepage" className="homepage-image" />
                <h1>Building Code Input</h1>
            </header>
            <main className="app-main">
                {/* Render the building code display only if there's a server response */}
                {currentBuildingInfo.serverResponse && Object.keys(currentBuildingInfo.serverResponse).length > 0 && (
                    <BuildingCodeDisplay buildingCodeData={currentBuildingInfo.serverResponse} />
                )}

                <BuildingForm
                    currentBuildingInfo={currentBuildingInfo}
                    setCurrentBuildingInfo={setCurrentBuildingInfo}
                    serverIp={serverIp}
                />

                <DatasetTable
                    serverIp={serverIp}
                    currentBuildingInfo={currentBuildingInfo}
                    setCurrentBuildingInfo={setCurrentBuildingInfo}
                />
            </main>
        </div>
    );
};

export default App;
