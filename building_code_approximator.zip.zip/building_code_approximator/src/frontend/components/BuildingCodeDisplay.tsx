import React from "react";

interface BuildingCodeDisplayProps {
    buildingCodeData: { [key: string]: any };
}

const BuildingCodeDisplay: React.FC<BuildingCodeDisplayProps> = ({ buildingCodeData }) => {
    if (!buildingCodeData || Object.keys(buildingCodeData).length === 0) {
        return null; // Render nothing if there's no building code data
    }

    const downloadCSV = () => {
        const keys = Object.keys(buildingCodeData);
        const values = Object.values(buildingCodeData).map(value => `"${value}"`); // Handle potential commas in values

        const csvContent = `data:text/csv;charset=utf-8,${keys.join(",")}\n${values.join(",")}`;
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "building_code.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="building-code-container">
            <h2 className="building-code-title">🏗️ Final Building Code</h2>
            <button className="download-button" onClick={downloadCSV}>⬇ Download CSV</button>
            <div className="building-code-content">
                <div className="building-code-scroll">
                    {Object.entries(buildingCodeData).map(([key, value], index) => (
                        <div key={index} className="building-code-item">
                            <span className="building-code-key">{key}:</span>
                            <span className="building-code-value">{value ? String(value) : "N/A"}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default BuildingCodeDisplay;
