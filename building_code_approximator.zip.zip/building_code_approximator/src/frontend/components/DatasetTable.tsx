import React, {useEffect, useState} from 'react';
import axios from 'axios';
import Loader from './Loader'; // Import the Loader component
import '../styles/styles.css';

interface DatasetTableProps {
    serverIp: string;
    currentBuildingInfo: { [key: string]: any };
    setCurrentBuildingInfo: React.Dispatch<React.SetStateAction<{ [key: string]: any }>>;
}

interface BuildingInfo {
    [key: string]: any;
}

interface AvailableCountries {
    "countries": string[];
}

const DatasetTable: React.FC<DatasetTableProps> = ({serverIp, currentBuildingInfo, setCurrentBuildingInfo}) => {
    const [dataset, setDataset] = useState<BuildingInfo[]>([]);
    const [availableCountries, setAvailableCountries] = useState<string[]>([]);
    const [dataLoading, setDataLoading] = useState<boolean>(true);
    const [countriesLoading, setCountriesLoading] = useState<boolean>(true);

    useEffect(() => {
        const fetchDataset = async () => {
            try {
                const datasetResponse = await axios.get<BuildingInfo[]>(`http://${serverIp}:5000/get_dataset`);
                const fetchedData = datasetResponse.data;
                setDataset(fetchedData);
                setDataLoading(false); // Set dataLoading to false after data is fetched
            } catch (error) {
                setDataLoading(false); // Set dataLoading to false even if there's an error
                throw error;
            }
        };
        fetchDataset().catch(error => console.error(error));
    }, [serverIp]);

    useEffect(() => {
        const fetchAvailableCountries = async () => {
            try {
                const availableCountriesResponse = await axios.get<AvailableCountries>(`http://${serverIp}:5000/countries`);
                const availableCountries = availableCountriesResponse.data;
                setAvailableCountries(availableCountries.countries)
                setCountriesLoading(false);
            } catch (error) {
                setCountriesLoading(false);
                throw error;
            }
        }
        fetchAvailableCountries().catch(error => console.error(error));
    }, []);
    const handleInfoChange = (key: keyof BuildingInfo, value: string) => {
        setCurrentBuildingInfo((prevInfo) => ({...prevInfo, [key]: value}));
    };

    const [availableCulturalNorms, setAvailableCulturalNorms] = useState<string[]>([]);
    const [culturalNormsLoading, setCulturalNormsLoading] = useState<boolean>(true);

    useEffect(() => {
        const fetchCulturalNorms = async () => {
            try {
                const culturalNormsResponse = await axios.get<{
                    cultural_norms: string[]
                }>(`http://${serverIp}:5000/cultural-norms`);
                const culturalNorms = culturalNormsResponse.data;
                setAvailableCulturalNorms(culturalNorms.cultural_norms);
                setCulturalNormsLoading(false);
            } catch (error) {
                setCulturalNormsLoading(false);
                throw error;
            }
        };
        fetchCulturalNorms().catch(error => console.error(error));
    }, [serverIp]);

    if (culturalNormsLoading) return <Loader/>; // Show loader while cultural norms are being fetched
    if (dataLoading) return <Loader/>; // Show loader while data is being fetched
    if (countriesLoading) return <Loader/>; // Show loader while data is being fetched
    const keys = dataset.length > 0 ? Object.keys(dataset[0]) : [];

    return (
        <div className="dataset-table">
            <table>
                <thead>
                <tr>
                    {keys.map((key, index) => (
                        <th key={index}>{key}</th>
                    ))}
                </tr>
                </thead>
                <tbody>
                <tr className="highlighted-row">
                    {keys.map((key, index) => (
                        key === 'Location' ? (
                            <td key={index} data-key={key}>
                                <select
                                    value={currentBuildingInfo[key as keyof BuildingInfo] || ''}
                                    onChange={(e) => handleInfoChange(key as keyof BuildingInfo, e.target.value)}
                                    className="editable-cell"
                                >
                                    <option value="" disabled>Select Country</option>
                                    {availableCountries.map((country, countryIndex) => (
                                        <option key={countryIndex} value={country}>{country}</option>
                                    ))}
                                </select>
                            </td>
                        ) : key === 'Cultural Norms' ? (
                            <td key={index} data-key={key}>
                                <select
                                    value=""
                                    onChange={(e) => {
                                        const selectedValue = e.target.value;
                                        if (selectedValue) {
                                            setCurrentBuildingInfo((prevInfo) => {
                                                const previousNorms = prevInfo[key as keyof BuildingInfo] || [];
                                                const updatedNorms = Array.isArray(previousNorms)
                                                    ? [...previousNorms, selectedValue].filter((v, i, a) => a.indexOf(v) === i)
                                                    : [selectedValue];
                                                return {...prevInfo, [key]: updatedNorms};
                                            });
                                        }
                                        e.target.value = ''; // Reset selection after adding
                                    }}
                                    className="editable-cell"
                                >
                                    <option value="" disabled>Select Cultural Norm</option>
                                    {availableCulturalNorms.map((norm, normIndex) => (
                                        <option key={normIndex} value={norm}>{norm}</option>
                                    ))}
                                </select>
                                <div>
                                    {Array.isArray(currentBuildingInfo[key as keyof BuildingInfo]) &&
                                        (currentBuildingInfo[key as keyof BuildingInfo] as string[]).map((norm, idx) => (
                                            <span key={idx} className="selected-norm"
                                                  style={{marginRight: '5px'}}>{norm}</span>
                                        ))}
                                </div>
                            </td>
                        ) : (
                            <td key={index} data-key={key}>
                                <input
                                    type="text"
                                    value={currentBuildingInfo[key as keyof BuildingInfo] || ''}
                                    onChange={(e) => handleInfoChange(key as keyof BuildingInfo, e.target.value)}
                                    placeholder={`Enter Value`}
                                    className="editable-cell"
                                />
                            </td>
                        )
                    ))}
                </tr>
                {dataset.map((row, rowIndex) => (
                    <tr key={rowIndex}>
                        {keys.map((key, colIndex) => (
                            <td key={colIndex}>{String(row[key as keyof BuildingInfo])}</td>
                        ))}
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
};

export default DatasetTable;
