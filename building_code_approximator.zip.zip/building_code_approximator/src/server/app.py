from flask import Flask, request, jsonify
from src.engine.geo_utils import calculate_distance
from src.engine.data_utils import get_dataset_ordered, get_countries, get_cultural_norms, approximate_building_code
from src.engine.env_manager import set_env_vars
import pandas as pd
import os
from flask_cors import CORS

# Load environment variables 
set_env_vars()

# Load dataset
DATASET_PATH = os.getenv('BUILDING_CODE_DATASET')  
df = pd.read_csv(DATASET_PATH)  


# Initialize the Flask application
app = Flask(__name__)
CORS(app)
# Define the endpoint '/distance'
@app.route('/distance', methods=['POST'])
def get_distance():
    
    # Ensure the request contains JSON
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    # Parse JSON request body
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid or missing JSON payload"}), 400

    # Extract coordinates from JSON body
    try:
        start_lat = float(data['start_lat'])
        start_lng = float(data['start_lng'])
        end_lat = float(data['end_lat'])
        end_lng = float(data['end_lng'])
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid coordinates"}), 400
    except KeyError:
        return jsonify({"error": "Missing coordinates"}), 400

    # Check if all required coordinates are provided
    if not all([start_lat, start_lng, end_lat, end_lng]):
        return jsonify({"error": "Missing coordinates"}), 400

    # Calculate distance
    source_coordinates = (start_lat, start_lng)
    destination_coordinates = (end_lat, end_lng)
    distance = calculate_distance(source_coordinates, destination_coordinates)

    
    return jsonify({"distance": distance})


@app.route('/get_dataset')
def get_dataset():
    return get_dataset_ordered()

@app.route('/countries', methods=['GET'])
def get_countries_list():

    """ Endpoint to return a list of available countries in the dataset."""
    return jsonify(get_countries())


@app.route('/cultural-norms', methods=['GET'])
def get_all_cultural_norms():

    """API endpoint to return a list of all unique cultural norms in the dataset."""

    return jsonify(get_cultural_norms())


@app.route('/approximate-building-code', methods=['POST'])
def get_approximate_building_code():
    approximated_code = approximate_building_code(request.json)
    return approximated_code

if __name__ == '__main__':
    app.run(debug=True, port=5000)