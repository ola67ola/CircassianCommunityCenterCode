import pandas as pd
import json
import os
from src.engine.env_manager import set_env_vars
set_env_vars()

mappers = json.load(open(os.path.join('src', 'shared', 'mappers.json'), 'r'))
dataset = pd.read_csv(os.getenv('BUILDING_CODE_DATASET'))

def get_countries(path_to_countries_file: str or os.PathLike = os.path.join('src', 'shared', 'countries.json')):
    return json.load(open(path_to_countries_file, 'r'))


def get_cultural_norms():
    return {"cultural_norms": mappers['cultural_norms']}

def encode_data(dataset: pd.DataFrame):
    climate_zones = mappers['climate_zones']
    dataset['Climate Zone'] = pd.Series([climate_zones.index(value.lower()) for value in dataset['Climate Zone']])

    cultural_norms = mappers['cultural_norms']
    dataset['Cultural Norms'] = pd.Series([[cultural_norms.index(val.lower()) for val in value.split(', ')] for value in dataset['Cultural Norms']])

    return dataset

def decode_data(dataset: pd.DataFrame):
    climate_zones = mappers['climate_zones']
    dataset['Climate Zone'] = pd.Series([climate_zones[int(value)] for value in dataset['Climate Zone']])

    cultural_norms = mappers['cultural_norms']
    dataset['Cultural Norms'] = pd.Series(["".join([cultural_norms[int(i)] + ', ' for i in value])[:-2] for value in dataset["Cultural Norms"]])

    return dataset

def sort_by_cultural_norms(source_cultural_norm: str, cultural_norms_series: pd.Series):

    exact_matches = []
    partial_matches = []
    rest = []

    source_lower = source_cultural_norm.lower()


    for i, norm in cultural_norms_series.items():
        norm_lower = norm.lower()
        if norm_lower == source_lower:
            exact_matches.append(i)
        elif source_lower in norm_lower and len(norm_lower) > len(source_lower):
            partial_matches.append(i)
        else:
            rest.append(i)

    return pd.Series(exact_matches + partial_matches + rest)

def clean_data(dataset: pd.DataFrame):
    dataset = dataset.replace(to_replace=pd.NA, value='N/A')
    dataset = dataset.replace(to_replace=pd.NaT, value='N/A')
    return dataset

def get_dataset_ordered():
    dataset_columns_order = mappers['dataset_columns_order']
    ordered_dataset = dataset[dataset_columns_order]
    ordered_dataset = clean_data(ordered_dataset)
    return ordered_dataset.to_json(orient='records')


def approximate_building_code(current_building_info: dict):
    # TODO: Build the approximation algorithm
    result = dataset.iloc[0][mappers['dataset_columns_order']]
    result = result.to_json()
    return result


if __name__ == '__main__':

    data_path = os.getenv('BUILDING_CODE_DATASET')

    data = pd.read_csv(data_path)

    encoded_data = encode_data(data)
    print(encoded_data.head())
    decoded_data = decode_data(encoded_data)
    print(decoded_data.head())

    cultural_norms_series = data['Cultural Norms']
    source_norm = "islam"
    sorted_indices = sort_by_cultural_norms(source_norm, cultural_norms_series)
    print(sorted_indices.head())

    print(approximate_building_code({'Location': 'Syria'}))