import requests
from typing import Tuple, Optional, List
from geopy.distance import geodesic
import os


google_maps_api_key = os.getenv('GOOGLE_MAPS_API_KEY')  # API key for Google Maps
google_maps_api_url = os.getenv('GOOGLE_MAPS_API_URL')  # Base URL for Google Maps API


def get_country_coordinates(country_name: str) -> Optional[Tuple[float, float]]:
    """
    Fetches the geographical coordinates (latitude and longitude) of a given country using Google Maps API.

    Args:
        country_name (str): Name of the country.

    Returns:
        Optional[Tuple[float, float]]: A tuple containing latitude and longitude if successful, None otherwise.
    """
    parameters = {
        'address': country_name,
        'key': google_maps_api_key
    }
    response = requests.get(url=google_maps_api_url, params=parameters)  # Make the API request

    data = response.json()  # Parse the response JSON
    if data['status'] == 'OK':  # Check if the response is successful
        location = data['results'][0]['geometry']['location']
        return location['lat'], location['lng']  # Return the coordinates

    # Print error message if the API call fails
    print(f"Error Message: {data.get('error_message', 'N/A')}")


def calculate_distance(source_coordinates: Tuple[float, float], destination_coordinates: Tuple[float, float]) -> float:
    """
    Calculates the geographical distance between two points using their coordinates.

    Args:
        source_coordinates (Tuple[float, float]): Tuple containing the latitude and longitude of the source location.
        destination_coordinates (Tuple[float, float]): Tuple containing the latitude and longitude of the destination location.

    Returns:
        float: Distance in kilometers between the two coordinates.
    """
    return geodesic(source_coordinates, destination_coordinates).kilometers


def sort_codes_by_geographical_proximity(target_country: str, countries: List[str]) -> List[int]:
    """
    Sorts a list of country names by their geographical proximity to a target country.

    Args:
        target_country (str): The name of the target country.
        countries (List[str]): A list of country names to sort.

    Returns:
        List[int]: A list of indices corresponding to the sorted order of the input list.
    """
    target_coordinates = get_country_coordinates(target_country)  # Get coordinates of the target country
    if target_country is None:  # Return None if target country coordinates are not found
        return None
    # Sort countries by proximity to the target country's coordinates
    sorted_countries = sorted(countries, key=lambda country: calculate_distance(target_coordinates,
                                                                                get_country_coordinates(country)))
    # Get the indices of the sorted countries in the original list
    sorted_countries = [countries.index(country) for country in sorted_countries]
    return sorted_countries


if __name__ == '__main__':
    """
    Main block for testing the functionality of the script.
    """
    countries = ["France", "Germany", "Italy", "Spain", "Portugal"]
    # Correct Order: [2 // Italy, 1 // Germany, 0 // France, 3 // Spain, 4 // Portugal]
    sorted_countries = sort_codes_by_geographical_proximity("Syria", countries)  # Sort the countries relative to Syria
    print(sorted_countries)  # Display the sorted indices
