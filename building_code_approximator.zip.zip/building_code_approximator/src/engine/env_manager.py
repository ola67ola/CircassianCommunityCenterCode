import os
from dotenv import load_dotenv, find_dotenv


def set_env_vars(env_path: str = 'secret/.dev.env'):
    # Load environment variables from the specified .env file
    load_dotenv(dotenv_path=env_path)

    # Find and load the .env file
    if not find_dotenv(env_path):
        print(f"The .env file at path '{env_path}' was not found.\n")
        print(f"If the required environment variables are not loaded into memory, the software will probably fail.")


    # Set the environment variables
    for key, value in os.environ.items():
        os.environ[key] = value



if __name__ == "__main__":
    set_env_vars('secret/.dev.env')
